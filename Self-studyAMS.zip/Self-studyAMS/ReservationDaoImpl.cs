﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Npgsql;

namespace Self_studyAMS
{
    class ReservationDaoImpl : IReservationDao
    {
        //数据库连接
        static string connString = "Host=localhost; Port=5432; Username=postgres; Password=157367qerw; Database=ReservationDB;";
        DataSet ds = new DataSet();
        NpgsqlConnection conn = null;
        NpgsqlDataAdapter nda = null;
        NpgsqlDataReader dr = null;
        private void connection()
        {
            return;
        }
        public List<Reservation> findAllReservation(string studentidid)
        {
            throw new NotImplementedException();
        }

        public void insertReservation(string studentid, string id)
        {
            throw new NotImplementedException();
        }

        public void updateReservation(Reservation reservation)
        {
            throw new NotImplementedException();
        }
        public void deleteReservation(string studentid)
        {
            throw new NotImplementedException();
        }
    }
}

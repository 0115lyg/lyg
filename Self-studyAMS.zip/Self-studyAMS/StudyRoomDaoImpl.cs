﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Npgsql;

namespace Self_studyAMS
{
    class StudyRoomDaoImpl : IStudyRoomDao
    {
        //数据库连接
        static string connString = "Host=localhost; Port=5432; Username=postgres; Password=157367qerw; Database=StudyRoomDB;";
        DataSet ds = new DataSet();
        NpgsqlConnection conn = null;
        NpgsqlDataAdapter nda = null;
        NpgsqlDataReader dr = null;
        private void connection()
        {
            return;
        }
        public List<string> findAllLibrary()
        {
            throw new NotImplementedException();
        }

        public List<string> findAllSeat(string library, string zone)
        {
            throw new NotImplementedException();
        }

        public List<string> findAllZone(string library)
        {
            throw new NotImplementedException();
        }

        public List<string> findState(string library, string zone, string seat)
        {
            throw new NotImplementedException();
        }

        public void insertStudyRoom(string library, string zone, string seat)
        {
            throw new NotImplementedException();
        }


        public void updateStudyRoom(StudyRoom studyRoom)
        {
            throw new NotImplementedException();
        }

        public void deleteStudyRoom(string library, string zone, string seat)
        {
            throw new NotImplementedException();
        }
    }
}

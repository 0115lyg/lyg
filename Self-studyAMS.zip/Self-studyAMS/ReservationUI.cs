﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Self_studyAMS
{
    public partial class ReservationUI : Form
    {
        public ReservationUI()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            StudyRoom x = new StudyRoom("", "", "", "", "", "", "");
            Reservation r = new Reservation("", "", "", "", "");
            r.Condition = "s";
        }
    }
}
